To connect the Node
    -npm i -g npm@latest


To create a React project cmd
    -npx create-react-app react-project


Rules to creatre components:
    1) First lettewr of the File Name of components is in Caps.
    2)File Name and Component name should be same
    3)In one file ypu can create only one compoonent


Types of components:
    1)Functional components
    2)Arrow Functional Components
    3) Class Components
