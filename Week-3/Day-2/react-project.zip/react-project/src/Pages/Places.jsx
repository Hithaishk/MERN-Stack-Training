import React from 'react';

function Places(){
    return(
        <>
            <h1>Places page</h1>
        </>
    )
}

export default Places;