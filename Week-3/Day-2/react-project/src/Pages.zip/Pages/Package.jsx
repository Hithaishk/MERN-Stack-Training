import React from 'react';

function Package(){
    return(
        <>
            <h1>Package page</h1>
        </>
    )
}

export default Package;